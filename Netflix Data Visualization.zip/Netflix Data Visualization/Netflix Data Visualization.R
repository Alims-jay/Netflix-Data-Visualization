library(ggplot2)
library(dplyr)
library(tidyr)

df <- read.csv("C:/Users/CARITAS_ADMIN/Desktop/Netflix Data Visualization/Netflix_shows_movies_cleaned.csv", stringsAsFactors = FALSE)

genre_counts <- df %>%
  separate_rows(listed_in, sep = ", ") %>%
  count(listed_in, sort = TRUE)

top_genres <- head(genre_counts, 10)

ggplot(top_genres, aes(x = reorder(listed_in, n), y = n, fill = listed_in)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Most Watched Genres on Netflix",
       x = "Genre",
       y = "Number of Titles") +
  theme_minimal() +
  theme(legend.position = "none")
